
// 1. Classes: inheritance, getters/setters, private fields, static method
class Person {
  #id; // private field (ES2022+)
  constructor(firstName, lastName) {
    this.firstName = firstName;
    this.lastName = lastName;
    this.#id = Math.floor(Math.random() * 1e6);
  }
  get fullName() {
    return `${this.firstName} ${this.lastName}`;
  }
  set fullName(value) {
    const [first, ...rest] = value.split(" ");
    this.firstName = first;
    this.lastName = rest.join(" ");
  }
  get id() { return this.#id; }

  static isPerson(obj) {
    return obj instanceof Person;
  }
}

class Student extends Person {
  constructor(firstName, lastName, level) {
    super(firstName, lastName);
    this.level = level;
  }
  describe = () => `${this.fullName} (Level: ${this.level})`; // arrow keeps lexical `this`
}

const alice = new Person("Alice", "Ade");
console.log("Person:", alice.fullName, "ID:", alice.id);
alice.fullName = "Alice A. Ade";
console.log("Updated fullName:", alice.fullName);

const bob = new Student("Bob", "Okoro", "200");
console.log("Student:", bob.describe());
console.log("isPerson(bob)?", Person.isPerson(bob));
