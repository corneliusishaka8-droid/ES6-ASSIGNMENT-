
// 6. Modules: named exports
export const add = (a, b) => a + b;
export const mul = (a, b) => a * b;
export const mean = arr => arr.reduce((s, n) => s + n, 0) / (arr.length || 1);
