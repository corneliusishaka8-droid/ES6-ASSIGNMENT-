
// 5. Destructuring: arrays, objects, defaults, renaming, nested, rest
const rgb = [255, 165, 0];
const [r, g, b] = rgb;
console.log("RGB:", r, g, b);

// Skip positions and provide defaults
const [first, , third = "defaultThird"] = ["A"];
console.log("first, third (with default):", first, third);

const person = { firstName: "Ngozi", lastName: "Okafor", address: { city: "Lagos", zip: "100001" } };

// Rename keys and set defaults
const { firstName: f, lastName: l, age = 21 } = person;
console.log("f, l, age(default 21):", f, l, age);

// Nested
const { address: { city, zip } } = person;
console.log("city, zip:", city, zip);

// Rest with arrays and objects
const [head, ...tail] = [1,2,3,4,5];
console.log("head:", head, "tail:", tail);

const { lastName, ...rest } = person;
console.log("lastName:", lastName, "| rest:", rest);
