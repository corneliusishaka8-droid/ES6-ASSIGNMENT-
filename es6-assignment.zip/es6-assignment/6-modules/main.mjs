
import { add, mul, mean } from "./math.mjs";
import titleCase from "./stringUtils.mjs";

const nums = [10, 20, 30];
console.log("add(2,3) =", add(2,3));
console.log("mul(4,5) =", mul(4,5));
console.log("mean([10,20,30]) =", mean(nums));
console.log("titleCase('hello from lagos') =", titleCase("hello from lagos"));
