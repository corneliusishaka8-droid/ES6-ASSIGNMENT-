
// 6. Modules: default export
const titleCase = (str) => {
  return String(str)
    .toLowerCase()
    .split(/\s+/)
    .map(w => w ? w[0].toUpperCase() + w.slice(1) : w)
    .join(" ");
};
export default titleCase;
