
// 8. Spread operator for arrays/objects (shallow copies)
const a = [1,2,3];
const b = [...a, 4, 5]; // clone + add
console.log("a:", a, "| b (spread):", b);

// Shallow copy note
const nested = [{ n: 1 }, { n: 2 }];
const copy = [...nested]; // copies array, not inner objects
copy[0].n = 99;
console.log("nested after modifying copy[0]:", nested);

// Objects
const user = { id: 1, name: "Amaka" };
const updated = { ...user, name: "Amaka Obi", role: "admin" };
console.log("user:", user, "| updated (spread):", updated);

// Merge with defaults
const defaults = { theme: "light", sidebar: true };
const settings = { sidebar: false };
const finalConfig = { ...defaults, ...settings };
console.log("finalConfig:", finalConfig);
