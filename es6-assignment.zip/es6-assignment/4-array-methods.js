
// 4. Array Methods: map, filter, reduce, find, some, every, sort
const nums = [5, 2, 9, 1, 5, 6];

const squares = nums.map(n => n * n);
console.log("map -> squares:", squares);

const evens = nums.filter(n => n % 2 === 0);
console.log("filter -> evens:", evens);

const sum = nums.reduce((acc, n) => acc + n, 0);
console.log("reduce -> sum:", sum);

const firstGreaterThan5 = nums.find(n => n > 5);
console.log("find -> first > 5:", firstGreaterThan5);

const hasNegative = nums.some(n => n < 0);
const allPositive = nums.every(n => n >= 0);
console.log("some negatives?", hasNegative, "| every >= 0?", allPositive);

// Sort ascending with comparator (never rely on default lexicographic sort for numbers)
const ascending = [...nums].sort((x, y) => x - y);
console.log("sort ascending:", ascending);
