
// 3. Variables: let/const vs var, block scope, TDZ
var a = 1; // function-scoped (legacy)
let b = 2; // block-scoped
const c = 3; // block-scoped + cannot be re-assigned (but objects can be mutated)

console.log("a,b,c:", a, b, c);

// Block scope
{
  let inside = "I exist only in this block";
  var leaks = "I leak outside (var)";
  console.log(inside);
}
console.log("var leaks is visible:", leaks);
// console.log(inside); // ReferenceError if uncommented

// Temporal Dead Zone (TDZ) example (do NOT uncomment next line)
// console.log(notYet); // Would throw ReferenceError due to TDZ
let notYet = "declared after use would error for let/const";
console.log(notYet);

// Const objects can be mutated (reference fixed, contents mutable)
const user = { name: "Zainab" };
user.name = "Zee"; // OK
console.log("const object mutated:", user);
