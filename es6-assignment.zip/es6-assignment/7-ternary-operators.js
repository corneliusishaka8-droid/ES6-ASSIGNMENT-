
// 7. Ternary operator (condition ? exprIfTrue : exprIfFalse)
const score = 72;
const grade = score >= 70 ? "A" : score >= 60 ? "B" : "C";
console.log("score:", score, "grade:", grade);

// Using ternary for small inline decisions
const isLoggedIn = false;
const btnText = isLoggedIn ? "Logout" : "Login";
console.log("btnText:", btnText);
