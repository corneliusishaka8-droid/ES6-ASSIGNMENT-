
# ES6 Assignment (JavaScript)

This folder contains simple, self-contained examples that demonstrate each requested ES6 concept.
You can run each file with Node.js (v14+ recommended; v18+ preferred).

## Files
1. `1-classes.js` — Classes, inheritance, getters/setters, private fields, static members.
2. `2-arrow-functions.js` — Arrow functions, implicit returns, lexical `this`.
3. `3-variables.js` — `let`, `const`, block scope, (contrast with `var`), and the "temporal dead zone".
4. `4-array-methods.js` — `map`, `filter`, `reduce`, `find`, `some`, `every`, `sort` with custom comparator.
5. `5-destructuring.js` — Array & object destructuring, defaults, renaming, nested, rest.
6. `6-modules/` — ES modules: `math.mjs`, `stringUtils.mjs`, `main.mjs`.
7. `7-ternary-operators.js` — Ternary (conditional) operator examples.
8. `8-spread-operators.js` — Spread syntax for arrays/objects; shallow copy notes.

## How to run (Node.js)
```bash
# From this folder
node 1-classes.js
node 2-arrow-functions.js
node 3-variables.js
node 4-array-methods.js
node 5-destructuring.js
node 7-ternary-operators.js
node 8-spread-operators.js

# ES modules use .mjs extension:
node 6-modules/main.mjs
```

## Notes
- All examples log results to the console.
- The module examples use `.mjs` so you don't need a `package.json` with `"type": "module"`.
