
// 2. Arrow Functions: implicit return, parameters, lexical this
const square = x => x * x; // implicit return
const sum = (a, b) => a + b;
const toUpper = s => String(s).toUpperCase();

console.log("square(5):", square(5));
console.log("sum(2, 3):", sum(2, 3));
console.log("toUpper('hello'):", toUpper("hello"));

// Lexical `this` example
const counter = {
  value: 0,
  start() {
    // Arrow function uses lexical `this` (counter), not its own.
    const tick = () => { this.value++; };
    tick(); tick(); tick();
  }
};
counter.start();
console.log("counter.value after start():", counter.value);
